package com.jetbreed.andriodlifecycle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class VictorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.victor);
    }
}