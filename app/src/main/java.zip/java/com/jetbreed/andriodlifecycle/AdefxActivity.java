package com.jetbreed.andriodlifecycle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AdefxActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.adefx);
    }
}